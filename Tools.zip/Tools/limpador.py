import os
import ultra_omega_alpha_kmeans
import ultra_omega_alpha_kmeans_multicore
import pickle
while('Trabalho-de-IA' not in os.listdir()):
	os.chdir('..')
os.chdir('Trabalho-de-IA')
os.chdir('Objetos')
os.chdir('ObjetosProcessados')

def VisitarAmiguinhos(directory):
	amigos=os.listdir(directory)
	for amigo in amigos:
		nomeamigo=os.path.join(directory,amigo)
		if(os.path.isdir(nomeamigo)):
			VisitarAmiguinhos(nomeamigo)
		else:
			if('.cluster' in amigo):
				print("Conversando com o amigo ",amigo)
				kmeans=pickle.load(open(nomeamigo,'rb'))
				kmeans.dados=None
				pickle.dump(kmeans,open(nomeamigo,'wb'))


VisitarAmiguinhos('.')